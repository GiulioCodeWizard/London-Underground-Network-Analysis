"""
Group 10-1
University of Greenwich 2° Year
Task 4 for COMP1828
"""

from mst import kruskal  # library used for calculating the minimum spanning tree
from task3 import AdjacencyListGraph, journey_durations, histogram, lines  # importing methods used in task3.py


def main():
    closed, station_names = [], []
    line_names = list(lines.keys())  # underground London lines

    for stations, connections in lines.values():
        for station in stations:
            if station not in station_names:
                station_names.append(station)  # extracting unique stations (non-duplicated)

    tube_graph = AdjacencyListGraph(len(station_names), False, True)  # initialising the graph

    added_edges = set()  # used for tracking added edges and prevent duplicate entries because in the case for ex. of
    # [A -- B] and [B -- A] I only count them once
    # Going through each underground line and for each connection between start and end stations I'm checking if the
    # edge has already been added (in both directions) and, if not, inserts the edge into the graph using the specified
    # duration or a default value of 1 for weight-stops
    for line_name in line_names:
        stations, connections = lines[line_name]
        for start_station, end_station, duration in connections:
            start, end = station_names.index(start_station), station_names.index(end_station)
            if (start, end) not in added_edges and (end, start) not in added_edges:
                tube_graph.insert_edge(start, end, duration if duration else 1)
                added_edges.add((start, end))

    mst = kruskal(tube_graph)  # using kruskal's algorithm to find the minimum spanning tree
    for start, end in added_edges:
        if not mst.has_edge(start, end):
            closed.append((station_names[start], station_names[end]))  # if the edge is not part of the minimum spanning
            # tree, it flags it as 'closed'

    print('=' * 44)
    print('Closed Line Sections:')
    print('=' * 44)
    for start, end in closed:
        print(f"{start} -- {end}")  # displaying the closed sections as pairs

    durations, longest_duration, duration_path,total_journeys  = journey_durations(station_names, mst)
    histogram(durations, 'Distribution of Journey Durations (Reduced Network)',
               'Journey Duration (Minutes)', 'skyblue')

    print('\n' + '*' * 120)
    print(f"The longest journey duration for the reduced London Underground system is {longest_duration} minutes\n")
    print('Duration path:', ' => '.join(duration_path[:5]) + ' => ')
    for k in range(5, (len(duration_path) - 3), 5):
        print(' ' * 15 + ' => '.join(duration_path[k:k + 5]) + ' => ')
    print(' ' * 15 + ' => '.join(duration_path[-3:]))
    print('\n' + '*' * 120)

if __name__ == '__main__':
    main()
