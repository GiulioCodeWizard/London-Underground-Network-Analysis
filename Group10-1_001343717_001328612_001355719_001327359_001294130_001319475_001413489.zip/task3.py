"""
Group 10-1
University of Greenwich 2° Year
Task 3 for COMP1828
"""

from underground_lines import lines  # importing data extracted manually from 'London Underground Data.xlsx'
from task1 import AdjacencyListGraph, dijkstra, plt  # libraries and methods used in task1.py
from time import sleep  # used for the bar loading functions
import sys  # used for the bar loading function


def journey_durations(stations, graph):  # calculating journey durations for all station pairs
    longest_duration, durations, longest_path = 0, [], []  # for calculating the longest duration I could have used also
    # the max() method
    total_journeys = 0  # counter for the total number of journeys calculated
    for st_st_i in range(len(stations)):  # looping throughout station pairs (start to destination)
        distances, predecessors = dijkstra(graph, st_st_i)  # taking the shortest distances from the start station
        # using dijkstra's algorithm imported from the clrsPython zip folder given under the specifications section
        for dest_st_i in range((st_st_i + 1), len(stations)):  # avoiding duplicates by starting from start + 1 as the
            # duration from station 1 to station 2 is the same from station 2 to station 1 for example
            journey_time = distances[dest_st_i]  # storing journey times to destination
            total_journeys += 1  # incrementing journey count
            if journey_time < float('inf'):
                durations.append(journey_time)  # storing the journey time durations which are 'correct'. If it's set to
                # infinity it means it's not a valid journey so we don't need it in our 'dataset' for the calculation of
                # journey times and later for the histogram graph

                # calculating the longest path by storing them step by step and going backwards to build the
                # intermediate stops and finally displaying it using the reverse() method from the start station to the
                # destination station
                if journey_time > longest_duration:
                    longest_duration = journey_time
                    longest_path = []

                    curr_station = dest_st_i
                    while curr_station != st_st_i:
                        longest_path.append(stations[curr_station])
                        curr_station = predecessors[curr_station]

                    longest_path.append(stations[st_st_i])
                    longest_path.reverse()

    return durations, longest_duration, longest_path, total_journeys


def journey_stops(stations, graph):
    longest_stops, stops, longest_path = 0, [], []

    for st_st_i in range(len(stations)):  # looping throughout station pairs (start to destination)
        distances, predecessors = dijkstra(graph, st_st_i)  # taking the shortest distances from the start station

        for dest_st_i in range((st_st_i + 1), len(stations)):  # avoiding duplicates by starting from start + 1 as the
            # duration from station 1 to station 2 is the same from station 2 to station 1 for example
            if distances[dest_st_i] < float('inf'):
                # initialising the number of stops and calculating the longest path by storing them step by step and
                # going backwards to build the intermediate stops while incrementing the stop count along the way and
                # finally displaying it using the reverse() method from the start station to the destination station
                num_stops, path = 0, []
                curr_station = dest_st_i

                while curr_station != st_st_i:
                    path.append(stations[curr_station])
                    num_stops += 1
                    curr_station = predecessors[curr_station]

                path.append(stations[st_st_i])
                path.reverse()
                stops.append(num_stops)

                if num_stops > longest_stops:
                    longest_stops = num_stops
                    longest_path = path

    return stops, longest_stops, longest_path


def loading_bar(duration=6, length=99):  # length of the bar and the duration of going "through" this bar
    print("Loading...")
    for i in range(length + 1):
        percent = (i / length) * 100
        bar = '█' * i + '-' * (length - i)
        sys.stdout.write(f'\r|{bar}| {percent:.1f}%')  # updating the loading bar on the same line
        sys.stdout.flush()
        sleep(duration / length)


def histogram(data, title, xlabel, color):
    plt.figure(figsize=(12, 8))  # window size
    plt.hist(data, bins=30, color=color, label='Frequency', edgecolor='black')  # variable reference
    plt.title(title)  # window title
    plt.xlabel(xlabel)  # x axes title
    plt.ylabel('Frequency')  # y axes title
    plt.legend()
    plt.grid(True)  # shown as grid table
    plt.show()


def main():
    station_names = []
    line_names = list(lines.keys())  # underground London lines

    for stations, connections in lines.values():
        for station in stations:
            if station not in station_names:
                station_names.append(station)  # extracting unique stations (non-duplicated)

    tube_graph = AdjacencyListGraph(len(station_names), False, True)  # initialising the graph

    added_edges = set()  # used for tracking added edges and prevent duplicate entries because in the case for ex. of
    # [A -- B] and [B -- A] I only count them once
    # Going through each underground line and for each connection between start and end stations I'm checking if the
    # edge has already been added (in both directions) and, if not, inserts the edge into the graph using the specified
    # duration or a default value of 1 for weight-stops
    for line_name in line_names:
        stations, connections = lines[line_name]
        for start_station, end_station, duration in connections:
            start, end = station_names.index(start_station), station_names.index(end_station)
            if (start, end) not in added_edges and (end, start) not in added_edges:
                tube_graph.insert_edge(start, end, duration if duration else 1)
                added_edges.add((start, end))

    loading_bar()  # loading bar for displaying the waiting time on the terminal
    durations, longest_duration, duration_path, total_journeys = journey_durations(station_names, tube_graph)
    stops, longest_stops, stops_path = journey_stops(station_names, tube_graph)

    histogram(durations, 'Distribution of Journey Durations (Minutes)', 'Journey Duration (Minutes)',
               'skyblue')
    histogram(stops, 'Distribution of Number of Stops', 'Number of Stops', 'lightgreen')

    print('\n' + '*' * 100)
    print(f"Total number of journey durations calculated: {total_journeys}")
    print("Duplicate journeys included/excluded: Excluded")
    print('\n' + '*' * 100)
    print(f"The longest journey duration is {longest_duration} minutes\n")
    print('Duration path:', ' => '.join(duration_path[:5]) + ' => ')
    for k in range(5, (len(duration_path) - 3), 5):
        print(' ' * 15 + ' => '.join(duration_path[k:k + 5]) + ' => ')
    print(' ' * 15 + ' => '.join(duration_path[-3:]))
    print('\n' + '*' * 100)
    print(f"The longest journey has: {longest_stops} stops\n")
    print('Stops path:', ' => '.join(stops_path[:5]) + ' => ')
    for j in range(5, (len(stops_path) - 3), 5):
        print(' ' * 12 + ' => '.join(stops_path[j:j + 5]) + ' => ')
    print(' ' * 12 + ' => '.join(stops_path[-3:]))
    print('\n' + '*' * 100)


if __name__ == "__main__":
    main()
