"""
Group 10-1
University of Greenwich 2° Year
Task 2 for COMP1828
"""

# libraries and methods used in task1.py
from task1 import AdjacencyListGraph, dijkstra, print_path, plot_execution_times, generate_random_graph, time, randint


def shortest_path(graph, st_st, dest_st, stations):  # function to calculate the shortest path between 2 edges [A -- B]
    # an adjacency list is memory-efficient for sparse graphs and aligns well with dijkstra's algorithm
    st_index = stations.index(st_st)  # getting the index of the starting station from the list of stations
    end_index = stations.index(dest_st)  # getting the index of the destination station from the list of stations
    distances, predecessors = dijkstra(graph, st_index)  # using dijkstra's algorithm to find the shortest
    # distances and predecessors from the starting station
    journey_time = distances[end_index]  # calculate the journey time to the destination station

    # printing the path from the predecessors list using the print_path function
    path = print_path(predecessors, st_index, end_index, lambda i: stations[i])

    return journey_time, path


def print_network(edges):
    # Displaying stations and edges in a table-format (I have divided it into a total of 44 cells and the 3 columns [
    # From], [To], [Stops] into 7, 7, 30 cells respectively so the sum is 44 and the output is more readable on the
    # terminal)
    print('Tube Network Stations and Stops:')
    print('=' * 50)
    print(f"{'From':<7} {'To':<7} {'Stops (count)':<30}")
    print('-' * 50)

    for st1, st2, stops in edges:
        print(f"{st1:<7} {st2:<7} {stops:<30}")
    print('=' * 50)


def execution_time(n):
    tube_graph = generate_random_graph(n, 0.25, True,False, True, 1, 1)
    vertices = (list(range(n)))
    # initialising the graph for the tube network giving as parameters the number of vertices, range of weights [MIN,
    # MAX] and managing also the direction by saying for example in an edge between A -- B for example means I can
    # travel freely in both directions from station A to station B and vice versa
    st_time = time()
    for i in range(100):  # measuring the time taken to calculate the shortest path for random station pairs
        # (used 100 for more accuracy in the answers)
        st_st = vertices[randint(0, n - 1)]
        dest_st = vertices[randint(0, n - 1)]
        shortest_path(tube_graph, st_st, dest_st, vertices)
    end_time = time()

    edges = 0  # counting the number of edges in the graph using method from DLLSentinel
    for nSt in tube_graph.adj_lists:
        for _ in nSt.iterator():
            edges += 1

    edges //= 2  # dividing by 2 for undirected graph
    avg_time = (end_time - st_time) / 100  # Average time for one path

    return avg_time, edges


def main():
    times = []
    edges_counts = []
    network_sizes = list(range(1100, 2001, 100))

    # Creating tube with 5 stations ('A', 'B', 'C', 'D', 'E')
    stations = ['A', 'B', 'C', 'D', 'E']
    edges = [
        ('A', 'B', 1),  # station 1 [A] to station 2 [B] => 1 stop
        ('A', 'C', 1),  # station 1 [A] to station 3 [C] => 1 stop
        ('B', 'C', 1),  # station 2 [B] to station 3 [C] => 1 stop
        ('B', 'D', 1),  # station 2 [B] to station 4 [D] => 1 stop
        ('C', 'D', 1),  # station 3 [C] to station 4 [D] => 1 stop
        ('C', 'E', 1),  # station 3 [C] to station 5 [E] => 1 stop
        ('D', 'E', 1),  # station 4 [D] to station 5 [E] => 1 stop
    ]

    print_network(edges)  # function call for displaying all the stations + edges in a table-base mode
    tube_graph = AdjacencyListGraph(len(stations), False, True)  # initialising the graph for
    # the tube network giving as parameters the length of the stations array and managing also the direction and the
    # weight. By saying directed=False, an edge between A -- B for example means I can travel freely in both
    # directions from station A to station B and vice versa. Weighted=True is important if I want to calculate the
    # shortest path between the edges

    for st1, st2, duration in edges:
        tube_graph.insert_edge(stations.index(st1), stations.index(st2), duration)  # inserting the edges into the
        # graph. As it is an undirected graph, now I'm inserting the edges in bidirectional way in one shot so
        # visiting from station A to station B and vice versa

    stations_test = [('A', 'D'), ('B', 'E'), ('E', 'A')]  # testing cases between random stations to check the
    # correctness of the solution by comparing it with a "manual" approach using pen and paper

    for st_station, dest_station in stations_test:  # looping through each test case to find and print the shortest path
        journey_time, path = shortest_path(tube_graph, st_station, dest_station, stations)
        print(f"{st_station} to {dest_station}: {journey_time} stops")
        print("Path:", " -> ".join(path))
        print('-' * 50)

    for n in network_sizes:  # looping through each network size to display the average execution time
        avg_time, num_edges = execution_time(n)
        times.append(avg_time * 1000)  # convert the result in milliseconds
        edges_counts.append(num_edges)
        print(f"Average execution time for {n} stations: {avg_time * 1000:.2f} ms")
        print(f"Total line sections (edges) for {n} stations: {num_edges}")
        print('°' * 50)

    plot_execution_times(network_sizes, times)  # function call for plotting a graph with the average execution time vs
    # network size


if __name__ == '__main__':
    main()
