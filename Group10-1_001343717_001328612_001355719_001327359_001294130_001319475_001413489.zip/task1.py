"""
Group 10-1
University of Greenwich 2° Year
Task 1 for COMP1828
"""

from time import time  # library used for calculating the execution time
from random import randint  # library used for creating random distances between edges [in minutes]
from dijkstra import dijkstra  # method used for efficiently calculating the shortest path from a starting node to all
# other nodes in both weighted & unweighted graphs
import matplotlib.pyplot as plt  # library used to plot the graph with the results [Avg Times x Num Networks]
from print_path import print_path  # display path from source to destination node in a clear format, helpful for
# visualising different routes
from adjacency_list_graph import AdjacencyListGraph  # efficient method in terms of memory for sparse graphs
from generate_random_graph import generate_random_graph  # used for generating random graph


def shortest_path(graph, st_st, dest_st, stations):  # function to calculate the shortest path between 2 edges [A -- B]
    # an adjacency list is memory-efficient for sparse graphs and aligns well with Dijkstra’s algorithm for representing
    # weighted edges
    st_index = stations.index(st_st)  # getting the index of the starting station from the list of stations
    end_index = stations.index(dest_st)  # getting the index of the destination station from the list of stations
    distances, predecessors = dijkstra(graph, st_index)  # using Dijkstra's algorithm to find the shortest
    # distances and predecessors from the starting station
    journey_time = distances[end_index]  # calculate the journey time to the destination station

    # printing the path from the predecessors list using the print_path function
    path = print_path(predecessors, st_index, end_index, lambda i: stations[i])

    return journey_time, path


def print_network(edges):
    # Printing stations and edges in a table-format (I have divided it into a total of 44 cells and the 3 columns [
    # From], [To], [Duration] into 7, 7, 30 cells respectively so the sum is 44 and the output is more readable on
    # the terminal)
    print('Tube Network Stations and Journey Durations:')
    print('=' * 50)
    print(f"{'From':<7} {'To':<7} {'Duration (minutes)':<30}")
    print('-' * 50)

    for st1, st2, duration in edges:
        print(f"{st1:<7} {st2:<7} {duration:<30}")
    print('=' * 50)


def execution_time(n):
    tube_graph = generate_random_graph(n, 0.25, True,False, True, 3, 7)
    vertices = (list(range(n)))
    # initialising the graph for the tube network giving as parameters the number of vertices, range of weights [MIN,
    # MAX] and managing also the direction by saying for example in an edge between A -- B for example means I can
    # travel freely in both directions from station A to station B and vice versa
    st_time = time()
    for i in range(100):  # measuring the time taken to calculate the shortest path for random station pairs
        # (used 100 for more accuracy in the answers)
        st_st = vertices[randint(0, n - 1)]
        dest_st = vertices[randint(0, n - 1)]
        shortest_path(tube_graph, st_st, dest_st, vertices)
    end_time = time()

    edges = 0  # counting the number of edges in the graph
    for nSt in tube_graph.adj_lists:
        for _ in nSt.iterator():
            edges += 1

    edges //= 2  # dividing by 2 for undirected graph
    avg_time = (end_time - st_time) / 100  # Average time for one path

    return avg_time, edges

def plot_execution_times(network_sizes, times):  # plotting a graph with the average execution time on the vertical axis
    # and the network size on the horizontal axis.
    plt.figure(figsize=(12, 8))  # window size
    plt.plot(network_sizes, times, label='Execution Time (ms)', linestyle='--', marker='o', color='teal')
    plt.title("Average Execution Time vs Network Size")  # window title
    plt.xlabel("Network Size (Number of Stations)")  # x axes title
    plt.ylabel("Average Execution Time (ms)")  # y axes title
    plt.legend()
    plt.grid(True)  # shown as grid table
    plt.show()


def main():
    times = []
    edges_counts = []
    network_sizes = list(range(100, 1001, 100))
    # Creating tube with 5 stations ('A', 'B', 'C', 'D', 'E')
    stations = ['A', 'B', 'C', 'D', 'E']
    edges = [
        ('A', 'B', randint(1, 10)),  # station 1 [A] to station 2 [B] => random minutes
        ('A', 'C', randint(1, 20)),  # station 1 [A] to station 3 [C] => random minutes
        ('B', 'C', randint(1, 10)),  # station 2 [B] to station 3 [C] => random minutes
        ('B', 'D', randint(1, 20)),  # station 2 [B] to station 4 [D] => random minutes
        ('C', 'D', randint(1, 10)),  # station 3 [C] to station 4 [D] => random minutes
        ('C', 'E', randint(1, 20)),  # station 3 [C] to station 5 [E] => random minutes
        ('D', 'E', randint(1, 10)),  # station 4 [D] to station 5 [E] => random minutes
    ]

    print_network(edges)  # function call for displaying all the stations + edges in a table-base mode
    tube_graph = AdjacencyListGraph(len(stations), False, True)  # initialising the graph for
    # the tube network giving as parameters the length of the stations array and managing also the direction and the
    # weight. By saying directed=False, an edge between A -- B for example means I can travel freely in both
    # directions from station A to station B and vice versa. Weighted=True is important if I want to calculate the
    # shortest path between the edges

    for st1, st2, duration in edges:
        tube_graph.insert_edge(stations.index(st1), stations.index(st2), duration)  # inserting the edges into the
        # graph. As it is an undirected graph, now I'm inserting the edges in bidirectional way in one shot so
        # visiting from station A to station B and vice versa

    stations_test = [('A', 'D'), ('B', 'E'), ('E', 'A')]  # testing cases between random stations to check the
    # correctness of the solution by comparing it with a "manual" approach using pen and paper

    for st_station, dest_station in stations_test:  # looping through each test case to find and print the shortest path
        journey_time, path = shortest_path(tube_graph, st_station, dest_station, stations)
        print(f"{st_station} to {dest_station}: {journey_time} minutes")
        print("Path:", " -> ".join(path))
        print('-' * 50)

    for n in network_sizes:  # looping through each network size to display the average execution time
        avg_time, num_edges = execution_time(n)
        times.append(avg_time * 1000)  # convert the result in milliseconds
        edges_counts.append(num_edges)
        print(f"Average execution time for {n} stations: {avg_time * 1000:.2f} ms")
        print(f"Total line sections (edges) for {n} stations: {num_edges}")
        print('°' * 50)

    plot_execution_times(network_sizes, times)  # function call for plotting a graph with the average execution time vs
    # network size


if __name__ == '__main__':
    main()
